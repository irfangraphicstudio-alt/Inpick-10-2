/* INPICK Shopify Online Store 2.0 Interactive Scripts */
(() => {
  const WISHLIST_KEY = 'inpick_shopify_wishlist_v1';
  const RECENTLY_VIEWED_KEY = 'inpick_recently_viewed_v1';
  const countdownTimers = new WeakMap();
  const heroTimers = new WeakMap();
  const reviewTimers = new WeakMap();
  let globalListenersBound = false;

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatMoney(cents) {
    const numCents = Number(cents || 0);
    const fmt = window.INPICK?.moneyFormat;
    if (fmt && typeof fmt === 'string') {
      const amountFixed = (numCents / 100).toFixed(2);
      const amountNoDecimals = Math.round(numCents / 100).toString();
      const amountComma = amountFixed.replace('.', ',');
      if (fmt.includes('{{amount_no_decimals}}')) {
        return fmt.replace(/\{\{\s*amount_no_decimals\s*\}\}/g, amountNoDecimals).replace(/<[^>]*>/g, '');
      }
      if (fmt.includes('{{amount_with_comma_separator}}')) {
        return fmt.replace(/\{\{\s*amount_with_comma_separator\s*\}\}/g, amountComma).replace(/<[^>]*>/g, '');
      }
      if (fmt.includes('{{amount}}')) {
        return fmt.replace(/\{\{\s*amount\s*\}\}/g, amountFixed).replace(/<[^>]*>/g, '');
      }
    }
    return '$' + (numCents / 100).toFixed(2);
  }

  function showToast(message) {
    const toast = document.getElementById('inpick-toast');
    if (!toast) return;
    toast.textContent = message;
    toast.hidden = false;
    toast.style.cssText =
      'position:fixed;bottom:84px;right:20px;z-index:120;background:#142B4D;color:#fff;padding:0.65rem 1.1rem;border-radius:0.75rem;font-size:0.875rem;font-weight:600;box-shadow:0 12px 28px rgba(20,43,77,0.22);';
    window.clearTimeout(toast._hideTimer);
    toast._hideTimer = window.setTimeout(() => {
      toast.hidden = true;
    }, 2600);
  }

  function setFormStatus(form, message, type) {
    const statusEl = form?.querySelector('[data-pdp-form-status]');
    if (!statusEl) return;
    if (!message) {
      statusEl.hidden = true;
      statusEl.textContent = '';
      statusEl.className = 'inpick-pdp-form-status';
      return;
    }
    statusEl.textContent = message;
    statusEl.className = `inpick-pdp-form-status is-${type || 'success'}`;
    statusEl.hidden = false;
  }

  /* 1. Hero Carousel (3000ms autoplay + clean pause/resume + no duplicate timers) */
  function initCarousels(root = document) {
    root.querySelectorAll('[data-hero-carousel]').forEach((carousel) => {
      if (heroTimers.has(carousel)) {
        window.clearInterval(heroTimers.get(carousel));
        heroTimers.delete(carousel);
      }
      if (carousel.dataset.inpickBound === 'true') return;
      carousel.dataset.inpickBound = 'true';

      const track = carousel.querySelector('[data-hero-track]');
      const slides = carousel.querySelectorAll('.inpick-hero-slide');
      const dots = carousel.querySelectorAll('[data-hero-dot]');
      const prevBtn = carousel.querySelector('[data-hero-prev]');
      const nextBtn = carousel.querySelector('[data-hero-next]');
      if (!track || slides.length <= 1) return;

      let index = 0;
      const sectionEl = carousel.closest('[data-autoplay]');
      const autoplayEnabled = sectionEl?.dataset.autoplay !== 'false';
      const parsedSpeed = Number(sectionEl?.dataset.autoplaySpeed || 3000);
      const speed = Number.isFinite(parsedSpeed) && parsedSpeed >= 1000 ? parsedSpeed : 3000;

      const goTo = (nextIdx) => {
        index = (nextIdx + slides.length) % slides.length;
        track.style.transform = `translate3d(-${index * 100}%, 0, 0)`;
        slides.forEach((slide, i) => slide.classList.toggle('is-active', i === index));
        dots.forEach((dot, i) => {
          dot.classList.toggle('is-active', i === index);
          dot.setAttribute('aria-selected', i === index ? 'true' : 'false');
        });
      };

      const stopAutoplay = () => {
        const activeId = heroTimers.get(carousel);
        if (activeId) {
          window.clearInterval(activeId);
          heroTimers.delete(carousel);
        }
      };

      const startAutoplay = () => {
        stopAutoplay();
        if (!autoplayEnabled || document.hidden) return;
        const id = window.setInterval(() => goTo(index + 1), speed);
        heroTimers.set(carousel, id);
      };

      prevBtn?.addEventListener('click', () => {
        goTo(index - 1);
        startAutoplay();
      });
      nextBtn?.addEventListener('click', () => {
        goTo(index + 1);
        startAutoplay();
      });
      dots.forEach((dot, i) => {
        dot.addEventListener('click', () => {
          goTo(i);
          startAutoplay();
        });
      });

      carousel.addEventListener('mouseenter', stopAutoplay);
      carousel.addEventListener('mouseleave', startAutoplay);
      carousel.addEventListener('focusin', stopAutoplay);
      carousel.addEventListener('focusout', (e) => {
        if (!carousel.contains(e.relatedTarget)) {
          startAutoplay();
        }
      });
      carousel.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
          goTo(index - 1);
          startAutoplay();
        }
        if (e.key === 'ArrowRight') {
          goTo(index + 1);
          startAutoplay();
        }
      });

      let touchStartX = 0;
      carousel.addEventListener(
        'touchstart',
        (e) => {
          touchStartX = e.changedTouches[0]?.clientX || 0;
          stopAutoplay();
        },
        { passive: true }
      );
      carousel.addEventListener(
        'touchend',
        (e) => {
          const diff = (e.changedTouches[0]?.clientX || 0) - touchStartX;
          if (Math.abs(diff) > 40) {
            goTo(diff > 0 ? index - 1 : index + 1);
          }
          startAutoplay();
        },
        { passive: true }
      );

      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          stopAutoplay();
        } else if (document.body.contains(carousel)) {
          startAutoplay();
        }
      });

      startAutoplay();
    });
  }

  /* 2. Flash Deal Countdown */
  function initCountdowns(root = document) {
    root.querySelectorAll('[data-countdown-end]').forEach((el) => {
      if (countdownTimers.has(el)) {
        window.clearInterval(countdownTimers.get(el));
      }

      const endStr = el.dataset.countdownEnd;
      const expiredText = el.dataset.expiredText || 'Offer ended';
      const grid = el.querySelector('[data-countdown-grid]');
      const expiredEl = el.querySelector('[data-countdown-expired]');
      const daysEl = el.querySelector('[data-cd-days]');
      const hoursEl = el.querySelector('[data-cd-hours]');
      const minsEl = el.querySelector('[data-cd-mins]');
      const secsEl = el.querySelector('[data-cd-secs]');

      const endTime = Date.parse(endStr);
      if (Number.isNaN(endTime)) {
        if (grid) grid.hidden = true;
        if (expiredEl) {
          expiredEl.textContent = expiredText;
          expiredEl.hidden = false;
        }
        return;
      }

      const tick = () => {
        const diff = endTime - Date.now();
        if (diff <= 0) {
          if (grid) grid.hidden = true;
          if (expiredEl) {
            expiredEl.textContent = expiredText;
            expiredEl.hidden = false;
          }
          const id = countdownTimers.get(el);
          if (id) window.clearInterval(id);
          return;
        }
        const totalSecs = Math.floor(diff / 1000);
        const days = Math.floor(totalSecs / 86400);
        const hours = Math.floor((totalSecs % 86400) / 3600);
        const mins = Math.floor((totalSecs % 3600) / 60);
        const secs = totalSecs % 60;
        if (daysEl) daysEl.textContent = String(days).padStart(2, '0');
        if (hoursEl) hoursEl.textContent = String(hours).padStart(2, '0');
        if (minsEl) minsEl.textContent = String(mins).padStart(2, '0');
        if (secsEl) secsEl.textContent = String(secs).padStart(2, '0');
      };

      tick();
      const intervalId = window.setInterval(tick, 1000);
      countdownTimers.set(el, intervalId);
    });
  }

  /* 3. Predictive Search */
  function initPredictiveSearch(root = document) {
    root.querySelectorAll('[data-predictive-search-input]').forEach((input) => {
      if (input.dataset.inpickBound === 'true') return;
      input.dataset.inpickBound = 'true';
      const form = input.closest('[data-predictive-search-form]');
      const box = form?.querySelector('[data-predictive-search-results]');
      if (!box) return;

      let debounceId = null;
      input.addEventListener('input', () => {
        window.clearTimeout(debounceId);
        const q = input.value.trim();
        if (q.length < 2) {
          box.hidden = true;
          box.innerHTML = '';
          return;
        }

        debounceId = window.setTimeout(async () => {
          try {
            const url = `${window.INPICK.routes.predictive_search_url}?q=${encodeURIComponent(q)}&resources[type]=product&resources[limit]=6`;
            const res = await fetch(url);
            if (!res.ok) return;
            const data = await res.json();
            const products = data?.resources?.results?.products || [];
            if (!products.length) {
              box.innerHTML = `<p style="padding:0.75rem;margin:0;color:#64748B;">No matching products found.</p>`;
              box.hidden = false;
              return;
            }
            box.innerHTML = products
              .map((p) => {
                const numericPrice = Number(String(p.price ?? 0).replace(/,/g, ''));
                const displayPrice = Number.isFinite(numericPrice) ? `$${numericPrice.toFixed(2)}` : escapeHtml(p.price || '');
                return `
              <a href="${escapeHtml(p.url)}" class="inpick-pred-item">
                ${p.image ? `<img src="${escapeHtml(p.image)}" alt="">` : ''}
                <div>
                  <div style="font-weight:600;font-size:0.88rem;">${escapeHtml(p.title)}</div>
                  <div style="font-size:0.8rem;color:#7B2FEA;font-weight:700;">${displayPrice}</div>
                </div>
              </a>
            `;
              })
              .join('');
            box.hidden = false;
          } catch {
            box.hidden = true;
          }
        }, 220);
      });
    });
  }

  /* 4. Drawers & Header Dropdowns */
  function setDrawerState(drawer, open) {
    if (!drawer) return;
    drawer.hidden = !open;
    drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
  }

  function initHeaderInteractions(root = document) {
    root.querySelectorAll('[data-all-cats-trigger]').forEach((trigger) => {
      if (trigger.dataset.inpickBound === 'true') return;
      trigger.dataset.inpickBound = 'true';
      const menu = trigger.closest('[data-all-cats-dropdown]')?.querySelector('#InpickAllCategoriesMenu');
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!menu) return;
        const next = menu.hidden;
        menu.hidden = !next;
        trigger.setAttribute('aria-expanded', next ? 'true' : 'false');
      });
    });

    root.querySelectorAll('[data-mobile-nav-open]').forEach((btn) => {
      if (btn.dataset.inpickBound === 'true') return;
      btn.dataset.inpickBound = 'true';
      btn.addEventListener('click', () => setDrawerState(document.getElementById('InpickMobileDrawer'), true));
    });

    root.querySelectorAll('[data-mobile-nav-close]').forEach((btn) => {
      if (btn.dataset.inpickBound === 'true') return;
      btn.dataset.inpickBound = 'true';
      btn.addEventListener('click', () => setDrawerState(document.getElementById('InpickMobileDrawer'), false));
    });
  }

  /* 5. Native AJAX Cart */
  async function refreshCartDrawer() {
    const body = document.querySelector('[data-cart-drawer-body]');
    const footer = document.querySelector('[data-cart-drawer-footer]');
    const subtotalEl = document.querySelector('[data-cart-subtotal]');

    try {
      const res = await fetch(`${window.INPICK.routes.cart_url}.js`);
      const cart = await res.json();
      document.querySelectorAll('[data-cart-count]').forEach((el) => {
        el.textContent = String(cart.item_count);
      });

      if (!body) return;
      if (!cart.items.length) {
        body.innerHTML = `<p style="color:#64748B;">Your cart is currently empty.</p>`;
        if (footer) footer.hidden = true;
        return;
      }

      body.innerHTML = cart.items
        .map(
          (item) => `
        <div style="display:flex;gap:0.85rem;padding:0.75rem 0;border-bottom:1px solid #E9E4F2;">
          ${item.image ? `<img src="${escapeHtml(item.image)}" alt="" style="width:64px;height:64px;object-fit:contain;background:#F7F7FA;border-radius:0.5rem;">` : ''}
          <div style="flex:1;">
            <a href="${escapeHtml(item.url)}" style="font-weight:700;font-size:0.9rem;">${escapeHtml(item.product_title)}</a>
            ${item.variant_title ? `<div style="font-size:0.78rem;color:#64748B;">${escapeHtml(item.variant_title)}</div>` : ''}
            <div style="display:flex;align-items:center;justify-content:space-between;margin-top:0.5rem;">
              <div class="inpick-qty-stepper">
                <button type="button" class="inpick-qty-btn" data-cart-qty-key="${escapeHtml(item.key)}" data-cart-qty-val="${item.quantity - 1}">−</button>
                <span style="padding:0 0.5rem;font-weight:600;">${item.quantity}</span>
                <button type="button" class="inpick-qty-btn" data-cart-qty-key="${escapeHtml(item.key)}" data-cart-qty-val="${item.quantity + 1}">+</button>
              </div>
              <strong class="tabular-nums">${formatMoney(item.final_line_price)}</strong>
            </div>
          </div>
        </div>
      `
        )
        .join('');

      body.querySelectorAll('[data-cart-qty-key]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          await fetch(`${window.INPICK.routes.cart_change_url}.js`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: btn.dataset.cartQtyKey, quantity: Number(btn.dataset.cartQtyVal) })
          });
          refreshCartDrawer();
        });
      });

      if (subtotalEl) subtotalEl.textContent = formatMoney(cart.total_price);
      if (footer) footer.hidden = false;
    } catch {
      // Ignore network errors silently
    }
  }

  /* 6. Wishlist Manager */
  function getWishlist() {
    try {
      return JSON.parse(localStorage.getItem(WISHLIST_KEY) || '[]');
    } catch {
      return [];
    }
  }

  function saveWishlist(items) {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(items));
    renderWishlistUI();
  }

  function renderWishlistUI() {
    const items = getWishlist();
    document.querySelectorAll('[data-wishlist-count]').forEach((el) => {
      el.textContent = String(items.length);
    });
    document.querySelectorAll('[data-wishlist-toggle]').forEach((btn) => {
      const exists = items.some((i) => String(i.id) === String(btn.dataset.productId));
      btn.setAttribute('aria-pressed', exists ? 'true' : 'false');
    });

    const body = document.querySelector('[data-wishlist-drawer-body]');
    if (body) {
      if (!items.length) {
        body.innerHTML = `<p style="color:#64748B;">No saved items yet.</p>`;
      } else {
        body.innerHTML = items
          .map(
            (item) => `
          <div style="display:flex;align-items:center;gap:0.75rem;padding:0.7rem 0;border-bottom:1px solid #E9E4F2;">
            ${item.image ? `<img src="${escapeHtml(item.image)}" alt="" style="width:56px;height:56px;object-fit:contain;background:#F7F7FA;border-radius:0.5rem;">` : ''}
            <div style="flex:1;">
              <a href="${escapeHtml(item.url)}" style="font-weight:700;font-size:0.88rem;">${escapeHtml(item.title)}</a>
              <div style="font-size:0.82rem;color:#7B2FEA;font-weight:700;">${escapeHtml(item.price)}</div>
            </div>
            <button type="button" data-wishlist-remove="${escapeHtml(item.id)}" style="border:0;background:transparent;cursor:pointer;color:#64748B;" aria-label="Remove item">✕</button>
          </div>
        `
          )
          .join('');

        body.querySelectorAll('[data-wishlist-remove]').forEach((btn) => {
          btn.addEventListener('click', () => {
            saveWishlist(getWishlist().filter((i) => String(i.id) !== String(btn.dataset.wishlistRemove)));
          });
        });
      }
    }

    const pageGrid = document.querySelector('[data-wishlist-page-grid]');
    const pageEmpty = document.querySelector('[data-wishlist-page-empty]');
    if (pageGrid) {
      if (!items.length) {
        pageGrid.innerHTML = '';
        if (pageEmpty) pageEmpty.hidden = false;
      } else {
        if (pageEmpty) pageEmpty.hidden = true;
        pageGrid.innerHTML = items
          .map(
            (item) => `
          <article class="inpick-product-card">
            <div class="inpick-product-card__media inpick-ratio--square">
              <a href="${escapeHtml(item.url)}" class="inpick-product-card__img-link">
                ${item.image ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.title)}" class="inpick-product-card__img">` : ''}
              </a>
            </div>
            <div class="inpick-product-card__body">
              <h3 class="inpick-product-card__title"><a href="${escapeHtml(item.url)}">${escapeHtml(item.title)}</a></h3>
              <div class="inpick-product-card__footer">
                <span class="inpick-price-current tabular-nums">${escapeHtml(item.price)}</span>
                <button type="button" class="inpick-btn inpick-btn--secondary" style="padding:0.35rem 0.7rem;font-size:0.75rem;" data-wishlist-remove="${escapeHtml(item.id)}">Remove</button>
              </div>
            </div>
          </article>
        `
          )
          .join('');
        pageGrid.querySelectorAll('[data-wishlist-remove]').forEach((btn) => {
          btn.addEventListener('click', () => {
            saveWishlist(getWishlist().filter((i) => String(i.id) !== String(btn.dataset.wishlistRemove)));
          });
        });
      }
    }
  }

  /* 7. PDP Gallery, Multi-Option Variants, SKU & Recommendations */
  function initProductPage(root = document) {
    const gallery = root.querySelector('[data-pdp-gallery]');
    let setImageByMediaId = null;

    if (gallery && gallery.dataset.inpickBound !== 'true') {
      gallery.dataset.inpickBound = 'true';
      const imgs = Array.from(gallery.querySelectorAll('[data-pdp-main-img]'));
      const thumbs = Array.from(gallery.querySelectorAll('[data-pdp-thumb]'));
      const counter = gallery.querySelector('[data-pdp-counter]');
      const prev = gallery.querySelector('[data-pdp-prev]');
      const next = gallery.querySelector('[data-pdp-next]');
      let idx = Math.max(
        0,
        imgs.findIndex((img) => img.classList.contains('is-active'))
      );

      const setImage = (i) => {
        if (!imgs.length) return;
        idx = (i + imgs.length) % imgs.length;
        imgs.forEach((img, pos) => img.classList.toggle('is-active', pos === idx));
        thumbs.forEach((t, pos) => t.classList.toggle('is-active', pos === idx));
        if (counter) counter.textContent = `${idx + 1} / ${imgs.length}`;
      };

      setImageByMediaId = (mediaId) => {
        if (!mediaId) return;
        const targetIndex = imgs.findIndex((img) => String(img.dataset.mediaId) === String(mediaId));
        if (targetIndex >= 0) {
          setImage(targetIndex);
        }
      };

      gallery._setImageByMediaId = setImageByMediaId;
      prev?.addEventListener('click', () => setImage(idx - 1));
      next?.addEventListener('click', () => setImage(idx + 1));
      thumbs.forEach((t, pos) => t.addEventListener('click', () => setImage(pos)));
    } else if (gallery && typeof gallery._setImageByMediaId === 'function') {
      setImageByMediaId = gallery._setImageByMediaId;
    }

    const qtyInput = root.querySelector('[data-qty-input]');
    const minusBtn = root.querySelector('[data-qty-minus]');
    const plusBtn = root.querySelector('[data-qty-plus]');
    if (minusBtn && minusBtn.dataset.inpickBound !== 'true') {
      minusBtn.dataset.inpickBound = 'true';
      minusBtn.addEventListener('click', () => {
        if (!qtyInput) return;
        const current = Number(qtyInput.value) || 1;
        qtyInput.value = String(Math.max(1, current - 1));
        qtyInput.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
    if (plusBtn && plusBtn.dataset.inpickBound !== 'true') {
      plusBtn.dataset.inpickBound = 'true';
      plusBtn.addEventListener('click', () => {
        if (!qtyInput) return;
        const current = Number(qtyInput.value) || 1;
        qtyInput.value = String(Math.max(1, current + 1));
        qtyInput.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }

    const variantsScript = root.querySelector('[data-product-variants-json]');
    const selectorWrap = root.querySelector('[data-variant-selector]');
    if (variantsScript && selectorWrap && selectorWrap.dataset.inpickBound !== 'true') {
      selectorWrap.dataset.inpickBound = 'true';
      let variants = [];
      try {
        variants = JSON.parse(variantsScript.textContent || '[]');
      } catch {
        variants = [];
      }
      const pdpSection = selectorWrap.closest('[data-pdp-section]') || selectorWrap.closest('.inpick-pdp-section');
      const pdpForm = pdpSection?.querySelector('[data-pdp-form]');

      const syncOptionAvailability = () => {
        const fieldsets = Array.from(selectorWrap.querySelectorAll('.inpick-variant-fieldset'));
        const currentSelections = fieldsets.map((fs) => fs.querySelector('input:checked')?.value || '');

        fieldsets.forEach((fs, optIdx) => {
          fs.querySelectorAll('input[type="radio"]').forEach((input) => {
            const labelEl = fs.querySelector(`[data-option-label-for="${CSS.escape(input.id)}"]`);
            if (!labelEl) return;
            const candidate = variants.find((v) =>
              Array.isArray(v.options) &&
              v.options.every((optVal, i) => (i === optIdx ? optVal === input.value : optVal === currentSelections[i]))
            );
            const anyVariantAvailable = variants.some(
              (v) => Array.isArray(v.options) && v.options[optIdx] === input.value && v.available
            );
            const isSoldOut = candidate ? !candidate.available : !anyVariantAvailable;
            labelEl.classList.toggle('is-soldout', isSoldOut);
            labelEl.setAttribute('aria-disabled', isSoldOut ? 'true' : 'false');
          });
        });
      };

      const renderVariantPrice = (variant) => {
        const priceBlock = pdpSection?.querySelector('[data-pdp-price-block]');
        if (!priceBlock || !variant) return;
        const onSale = variant.compare_at_price && variant.compare_at_price > variant.price;
        const pct = onSale
          ? Math.round(((variant.compare_at_price - variant.price) * 100) / variant.compare_at_price)
          : 0;
        priceBlock.innerHTML = `
          <div class="inpick-price-wrap${onSale ? ' is-on-sale' : ''}">
            <span class="inpick-price-current tabular-nums">${formatMoney(variant.price)}</span>
            ${onSale ? `<s class="inpick-price-compare tabular-nums">${formatMoney(variant.compare_at_price)}</s>` : ''}
            ${onSale && pct > 0 ? `<span class="inpick-save-pill">Save ${pct}%</span>` : ''}
          </div>
        `;
      };

      const inventoryScript = pdpSection?.querySelector('[data-product-inventory-json]');
      let inventoryMap = {};
      if (inventoryScript) {
        try {
          inventoryMap = JSON.parse(inventoryScript.textContent || '{}');
        } catch {
          inventoryMap = {};
        }
      }

      const applyVariantSelection = (e) => {
        const fieldsets = Array.from(selectorWrap.querySelectorAll('.inpick-variant-fieldset'));
        const selectedOptions = fieldsets.map((fs) => fs.querySelector('input:checked')?.value || '');

        let match = variants.find(
          (v) => Array.isArray(v.options) && v.options.every((opt, i) => opt === selectedOptions[i])
        );

        if (!match && e?.target) {
          const changedFieldset = e.target.closest('.inpick-variant-fieldset');
          const changedIdx = fieldsets.indexOf(changedFieldset);
          const changedVal = e.target.value;
          if (changedIdx >= 0) {
            match =
              variants.find((v) => v.options?.[changedIdx] === changedVal && v.available) ||
              variants.find((v) => v.options?.[changedIdx] === changedVal);
          }
        }

        if (!match && selectedOptions.length) {
          match = variants.find((v) => v.options?.[0] === selectedOptions[0]) || variants[0];
        }

        if (match && Array.isArray(match.options)) {
          fieldsets.forEach((fs, i) => {
            const targetVal = match.options[i];
            if (targetVal !== undefined) {
              fs.querySelectorAll('input[type="radio"]').forEach((inp) => {
                inp.checked = inp.value === targetVal;
              });
              const label = fs.querySelector('[data-option-label]');
              if (label) label.textContent = targetVal;
            }
          });
        }

        syncOptionAvailability();
        setFormStatus(pdpForm, '', '');

        if (match) {
          const idInput = pdpSection?.querySelector('[data-variant-id-input]') || document.querySelector('[data-variant-id-input]');
          const addBtn = pdpSection?.querySelector('[data-pdp-add-btn]') || document.querySelector('[data-pdp-add-btn]');
          const addText = pdpSection?.querySelector('[data-pdp-add-text]') || document.querySelector('[data-pdp-add-text]');
          const stockStatus = pdpSection?.querySelector('[data-stock-status]') || document.querySelector('[data-stock-status]');
          const skuWrap = pdpSection?.querySelector('[data-pdp-sku-wrap]');
          const skuEl = pdpSection?.querySelector('[data-pdp-sku]');

          if (idInput) {
            idInput.value = match.id;
            idInput.dispatchEvent(new Event('change', { bubbles: true }));
          }
          if (addBtn) {
            addBtn.disabled = !match.available;
            addBtn.dataset.variantAvailable = match.available ? 'true' : 'false';
          }
          if (addText) addText.textContent = match.available ? 'Add to Cart' : 'Sold Out';
          if (stockStatus) {
            const invInfo = inventoryMap[String(match.id)];
            stockStatus.textContent = invInfo?.text || (match.available ? 'In Stock' : 'Sold Out');
            stockStatus.classList.toggle('is-soldout', !match.available);
            stockStatus.classList.toggle('is-low', invInfo?.state === 'low_stock');
          }
          if (skuWrap && skuEl) {
            const cleanSku = (match.sku || '').trim();
            skuEl.textContent = cleanSku;
            skuWrap.hidden = !cleanSku;
          }

          renderVariantPrice(match);

          const mediaId = match.featured_media?.id || match.featured_image?.id;
          const activeGallery = pdpSection?.querySelector('[data-pdp-gallery]');
          if (mediaId && activeGallery && typeof activeGallery._setImageByMediaId === 'function') {
            activeGallery._setImageByMediaId(mediaId);
          }

          try {
            const url = new URL(window.location.href);
            url.searchParams.set('variant', String(match.id));
            window.history.replaceState({}, '', url.toString());
          } catch {
            // Ignore URL update error in restricted contexts
          }
        }
      };

      syncOptionAvailability();
      selectorWrap.addEventListener('change', applyVariantSelection);
    }

    root.querySelectorAll('[data-product-recommendations]').forEach(async (rec) => {
      if (rec.dataset.inpickLoaded === 'true') return;
      rec.dataset.inpickLoaded = 'true';
      try {
        const res = await fetch(rec.dataset.url);
        if (!res.ok) {
          rec.hidden = true;
          return;
        }
        const html = await res.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const inner = doc.querySelector('[data-product-recommendations]');
        if (inner && inner.querySelectorAll('.inpick-product-card').length > 0) {
          rec.innerHTML = inner.innerHTML;
          rec.hidden = false;
          renderWishlistUI();
        } else {
          rec.hidden = true;
        }
      } catch {
        rec.hidden = true;
      }
    });

    const sortEl = root.querySelector('[data-collection-sort]');
    if (sortEl && sortEl.dataset.inpickBound !== 'true') {
      sortEl.dataset.inpickBound = 'true';
      sortEl.addEventListener('change', (e) => {
        const url = new URL(window.location.href);
        url.searchParams.set('sort_by', e.target.value);
        window.location.href = url.toString();
      });
    }
  }

  /* 8. Frequently Bought Together Bundle Calculator & Multi-Item Add to Cart */
  function initFrequentlyBoughtTogether(root = document) {
    root.querySelectorAll('[data-fbt-section]').forEach((section) => {
      if (section.dataset.inpickBound === 'true') return;
      section.dataset.inpickBound = 'true';

      const totalEl = section.querySelector('[data-fbt-total]');
      const countEl = section.querySelector('[data-fbt-selected-count]');
      const addBtn = section.querySelector('[data-fbt-add-btn]');
      const statusEl = section.querySelector('[data-fbt-status]');

      const updateSummary = () => {
        const checkboxes = Array.from(section.querySelectorAll('[data-fbt-checkbox]'));
        const selected = checkboxes.filter((cb) => cb.checked && !cb.disabled && cb.dataset.variantId);
        const totalCents = selected.reduce((sum, cb) => sum + Number(cb.dataset.price || 0), 0);

        if (countEl) countEl.textContent = String(selected.length);
        if (totalEl) totalEl.textContent = formatMoney(totalCents);
        if (addBtn) addBtn.disabled = selected.length === 0;
      };

      section.querySelectorAll('[data-fbt-variant-select]').forEach((select) => {
        select.addEventListener('change', () => {
          const opt = select.selectedOptions[0];
          const itemCard = select.closest('[data-fbt-item]');
          const cb = itemCard?.querySelector('[data-fbt-checkbox]');
          const priceSpan = itemCard?.querySelector('[data-fbt-item-price]');
          if (!opt || !cb) return;

          const newPrice = Number(opt.dataset.price || 0);
          const isAvailable = opt.dataset.available !== 'false';
          cb.dataset.variantId = opt.value;
          cb.dataset.price = String(newPrice);
          cb.disabled = !isAvailable;
          if (!isAvailable) cb.checked = false;
          itemCard.classList.toggle('is-unavailable', !isAvailable);
          if (priceSpan) priceSpan.textContent = formatMoney(newPrice);
          updateSummary();
        });
      });

      section.querySelectorAll('[data-fbt-checkbox]').forEach((cb) => {
        cb.addEventListener('change', updateSummary);
      });

      addBtn?.addEventListener('click', async () => {
        const selected = Array.from(section.querySelectorAll('[data-fbt-checkbox]')).filter(
          (cb) => cb.checked && !cb.disabled && cb.dataset.variantId
        );
        if (!selected.length) return;

        addBtn.disabled = true;
        if (statusEl) {
          statusEl.hidden = true;
          statusEl.textContent = '';
        }

        try {
          const items = selected.map((cb) => ({ id: Number(cb.dataset.variantId), quantity: 1 }));
          const addUrl = `${window.INPICK?.routes?.cart_add_url || '/cart/add'}.js`;
          const res = await fetch(addUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({ items })
          });
          const data = await res.json();
          if (!res.ok) {
            const msg = data?.description || 'Unable to add selected items to cart.';
            if (statusEl) {
              statusEl.textContent = msg;
              statusEl.className = 'inpick-fbt-status is-error';
              statusEl.hidden = false;
            }
            showToast(msg);
            return;
          }

          await refreshCartDrawer();
          if (statusEl) {
            statusEl.textContent = `Added ${items.length} item${items.length > 1 ? 's' : ''} to cart.`;
            statusEl.className = 'inpick-fbt-status is-success';
            statusEl.hidden = false;
          }
          if (window.INPICK?.cartType === 'drawer') {
            setDrawerState(document.getElementById('InpickCartDrawer'), true);
          } else {
            showToast(`Added ${items.length} selected item${items.length > 1 ? 's' : ''} to cart`);
          }
        } catch {
          if (statusEl) {
            statusEl.textContent = 'Network error adding bundle. Please try again.';
            statusEl.className = 'inpick-fbt-status is-error';
            statusEl.hidden = false;
          }
        } finally {
          updateSummary();
        }
      });

      updateSummary();
    });
  }

  /* 9. Recently Viewed Products Tracker & Real Shopify JSON Hydrator */
  function getRecentlyViewedHandles() {
    try {
      const raw = JSON.parse(localStorage.getItem(RECENTLY_VIEWED_KEY) || '[]');
      return Array.isArray(raw) ? raw.filter((h) => typeof h === 'string' && h.trim()) : [];
    } catch {
      return [];
    }
  }

  function recordCurrentProductHandle() {
    const pdpEl = document.querySelector('[data-pdp-section][data-product-handle]');
    const handle = pdpEl?.dataset.productHandle?.trim();
    if (!handle) return;
    try {
      const existing = getRecentlyViewedHandles().filter((h) => h !== handle);
      const updated = [handle, ...existing].slice(0, 12);
      localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(updated));
    } catch {
      // Ignore storage quota errors
    }
  }

  async function initRecentlyViewed(root = document) {
    recordCurrentProductHandle();
    const sections = root.querySelectorAll('[data-recently-viewed-section]');
    if (!sections.length) return;

    for (const section of sections) {
      if (section.dataset.inpickBound === 'true') continue;
      section.dataset.inpickBound = 'true';

      const currentHandle = (section.dataset.currentHandle || '').trim();
      const limit = Math.max(1, Math.min(8, Number(section.dataset.limit || 5)));
      const showQuickAdd = section.dataset.showQuickAdd !== 'false';
      const showWishlist = section.dataset.showWishlist !== 'false';
      const grid = section.querySelector('[data-recently-viewed-grid]');
      if (!grid) continue;

      const candidateHandles = getRecentlyViewedHandles()
        .filter((h) => h && h !== currentHandle)
        .slice(0, limit);

      if (!candidateHandles.length) {
        section.hidden = true;
        continue;
      }

      const rawRoot = window.INPICK?.routes?.root_url || '/';
      const rootPrefix = rawRoot.endsWith('/') ? rawRoot.slice(0, -1) : rawRoot;
      const missingHandles = [];

      const results = await Promise.allSettled(
        candidateHandles.map(async (handle) => {
          const res = await fetch(`${rootPrefix}/products/${encodeURIComponent(handle)}.js`);
          if (res.status === 404) {
            missingHandles.push(handle);
            return null;
          }
          if (!res.ok) return null;
          return res.json();
        })
      );

      if (missingHandles.length) {
        try {
          const pruned = getRecentlyViewedHandles().filter((h) => !missingHandles.includes(h));
          localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(pruned));
        } catch {
          // Ignore storage write errors
        }
      }

      const products = results
        .filter((r) => r.status === 'fulfilled' && r.value && r.value.id)
        .map((r) => r.value)
        .slice(0, limit);

      if (!products.length) {
        section.hidden = true;
        continue;
      }

      grid.innerHTML = products
        .map((prod) => {
          const variants = Array.isArray(prod.variants) ? prod.variants : [];
          const activeVariant = variants.find((v) => v.available) || variants[0] || {};
          const price = Number(activeVariant.price ?? prod.price ?? 0);
          const compareAt = Number(activeVariant.compare_at_price ?? prod.compare_at_price ?? 0);
          const onSale = compareAt > price && compareAt > 0;
          const discountPct = onSale ? Math.round(((compareAt - price) * 100) / compareAt) : 0;
          const imgSrc = prod.featured_image || (Array.isArray(prod.images) ? prod.images[0] : '') || '';
          const prodUrl = prod.url || `/products/${encodeURIComponent(prod.handle)}`;
          const variantAvailable = Boolean(activeVariant.available ?? prod.available);
          const variantId = activeVariant.id;

          return `
            <article class="inpick-product-card inpick-card-style--elevated">
              <div class="inpick-product-card__media inpick-ratio--square">
                ${
                  !prod.available
                    ? `<span class="inpick-card-badge is-soldout">Sold Out</span>`
                    : onSale && discountPct > 0
                      ? `<span class="inpick-card-badge is-sale tabular-nums">-${discountPct}%</span>`
                      : ''
                }
                ${
                  showWishlist && window.INPICK?.wishlistEnabled !== false
                    ? `<button
                        type="button"
                        class="inpick-wishlist-toggle"
                        data-wishlist-toggle
                        data-product-id="${escapeHtml(prod.id)}"
                        data-product-handle="${escapeHtml(prod.handle)}"
                        data-product-title="${escapeHtml(prod.title)}"
                        data-product-price="${escapeHtml(formatMoney(price))}"
                        data-product-url="${escapeHtml(prodUrl)}"
                        data-product-image="${escapeHtml(imgSrc)}"
                        aria-label="Add to Wishlist: ${escapeHtml(prod.title)}"
                        aria-pressed="false"
                      >
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                        </svg>
                      </button>`
                    : ''
                }
                <a href="${escapeHtml(prodUrl)}" class="inpick-product-card__img-link" aria-label="${escapeHtml(prod.title)}">
                  ${
                    imgSrc
                      ? `<img src="${escapeHtml(imgSrc)}" alt="${escapeHtml(prod.title)}" loading="lazy" width="480" height="480" class="inpick-product-card__img inpick-fit--contain">`
                      : ''
                  }
                </a>
              </div>
              <div class="inpick-product-card__body">
                <h3 class="inpick-product-card__title">
                  <a href="${escapeHtml(prodUrl)}">${escapeHtml(prod.title)}</a>
                </h3>
                <div class="inpick-product-card__footer">
                  <div class="inpick-price-wrap${onSale ? ' is-on-sale' : ''}">
                    <span class="inpick-price-current tabular-nums">${escapeHtml(formatMoney(price))}</span>
                    ${onSale ? `<s class="inpick-price-compare tabular-nums">${escapeHtml(formatMoney(compareAt))}</s>` : ''}
                  </div>
                  ${
                    showQuickAdd && variantId
                      ? `<form method="post" action="${escapeHtml(window.INPICK?.routes?.cart_add_url || '/cart/add')}" class="inpick-quick-add-form" data-ajax-cart-form>
                          <input type="hidden" name="id" value="${escapeHtml(variantId)}">
                          <input type="hidden" name="quantity" value="1">
                          <button
                            type="submit"
                            class="inpick-quick-add-btn"
                            data-variant-available="${variantAvailable}"
                            ${!variantAvailable ? 'disabled' : ''}
                            aria-label="Add to Cart: ${escapeHtml(prod.title)}"
                            title="Add to Cart"
                          >
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                              <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                            </svg>
                          </button>
                        </form>`
                      : ''
                  }
                </div>
              </div>
            </article>
          `;
        })
        .join('');

      section.hidden = false;
      renderWishlistUI();
    }
  }

  /* 10. Product Customer Reviews Responsive Slider */
  function initReviewSliders(root = document) {
    root.querySelectorAll('[data-reviews-slider]').forEach((slider) => {
      if (reviewTimers.has(slider)) {
        window.clearInterval(reviewTimers.get(slider));
        reviewTimers.delete(slider);
      }
      if (slider.dataset.inpickBound === 'true') return;
      slider.dataset.inpickBound = 'true';

      const track = slider.querySelector('[data-reviews-track]');
      const cards = Array.from(slider.querySelectorAll('[data-review-card]'));
      const controls = slider.querySelector('[data-reviews-controls]');
      const dotsWrap = slider.querySelector('[data-reviews-dots]');
      const prevBtn = slider.querySelector('[data-reviews-prev]');
      const nextBtn = slider.querySelector('[data-reviews-next]');

      if (!track || !cards.length) return;

      let currentIndex = 0;
      const autoplayEnabled = slider.dataset.autoplay !== 'false';
      const parsedSpeed = Number(slider.dataset.autoplaySpeed || 4500);
      const speed = Number.isFinite(parsedSpeed) && parsedSpeed >= 1500 ? parsedSpeed : 4500;

      const getPerView = () => {
        if (window.innerWidth >= 1024) return 3;
        if (window.innerWidth >= 768) return 2;
        return 1;
      };

      const getMaxIndex = () => Math.max(0, cards.length - getPerView());

      const renderDots = () => {
        if (!dotsWrap) return;
        const maxIndex = getMaxIndex();
        if (controls) controls.hidden = maxIndex <= 0;
        dotsWrap.innerHTML = '';
        for (let i = 0; i <= maxIndex; i += 1) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = `inpick-reviews-dot${i === currentIndex ? ' is-active' : ''}`;
          btn.setAttribute('role', 'tab');
          btn.setAttribute('aria-selected', i === currentIndex ? 'true' : 'false');
          btn.setAttribute('aria-label', `Show review group ${i + 1}`);
          btn.addEventListener('click', () => {
            goTo(i);
            startAutoplay();
          });
          dotsWrap.appendChild(btn);
        }
      };

      const updateTransform = () => {
        const maxIndex = getMaxIndex();
        if (currentIndex > maxIndex) currentIndex = 0;
        const cardWidth = cards[0]?.getBoundingClientRect().width || 0;
        const trackStyles = window.getComputedStyle(track);
        const gap = parseFloat(trackStyles.columnGap || trackStyles.gap || '16') || 16;
        const offsetPx = currentIndex * (cardWidth + gap);
        track.style.transform = `translate3d(-${offsetPx}px, 0, 0)`;

        if (dotsWrap) {
          dotsWrap.querySelectorAll('.inpick-reviews-dot').forEach((dot, i) => {
            dot.classList.toggle('is-active', i === currentIndex);
            dot.setAttribute('aria-selected', i === currentIndex ? 'true' : 'false');
          });
        }
      };

      const goTo = (nextIdx) => {
        const maxIndex = getMaxIndex();
        if (maxIndex <= 0) {
          currentIndex = 0;
          updateTransform();
          return;
        }
        if (nextIdx > maxIndex) currentIndex = 0;
        else if (nextIdx < 0) currentIndex = maxIndex;
        else currentIndex = nextIdx;
        updateTransform();
      };

      const stopAutoplay = () => {
        const activeId = reviewTimers.get(slider);
        if (activeId) {
          window.clearInterval(activeId);
          reviewTimers.delete(slider);
        }
      };

      const startAutoplay = () => {
        stopAutoplay();
        if (!autoplayEnabled || getMaxIndex() <= 0 || document.hidden) return;
        const id = window.setInterval(() => goTo(currentIndex + 1), speed);
        reviewTimers.set(slider, id);
      };

      prevBtn?.addEventListener('click', () => {
        goTo(currentIndex - 1);
        startAutoplay();
      });
      nextBtn?.addEventListener('click', () => {
        goTo(currentIndex + 1);
        startAutoplay();
      });

      slider.addEventListener('mouseenter', stopAutoplay);
      slider.addEventListener('mouseleave', startAutoplay);
      slider.addEventListener('focusin', stopAutoplay);
      slider.addEventListener('focusout', (e) => {
        if (!slider.contains(e.relatedTarget)) {
          startAutoplay();
        }
      });

      let touchStartX = 0;
      slider.addEventListener(
        'touchstart',
        (e) => {
          touchStartX = e.changedTouches[0]?.clientX || 0;
          stopAutoplay();
        },
        { passive: true }
      );
      slider.addEventListener(
        'touchend',
        (e) => {
          const diff = (e.changedTouches[0]?.clientX || 0) - touchStartX;
          if (Math.abs(diff) > 40) {
            goTo(diff > 0 ? currentIndex - 1 : currentIndex + 1);
          }
          startAutoplay();
        },
        { passive: true }
      );

      let resizeTimer = null;
      window.addEventListener('resize', () => {
        window.clearTimeout(resizeTimer);
        resizeTimer = window.setTimeout(() => {
          renderDots();
          updateTransform();
        }, 120);
      });

      renderDots();
      updateTransform();
      startAutoplay();
    });
  }

  /* 11. Global Delegated Listeners (survive Shopify Theme Editor section reloads) */
  function bindGlobalListeners() {
    if (globalListenersBound) return;
    globalListenersBound = true;

    document.addEventListener('click', (e) => {
      if (!e.target.closest('[data-all-cats-dropdown]')) {
        const menu = document.getElementById('InpickAllCategoriesMenu');
        const trigger = document.querySelector('[data-all-cats-trigger]');
        if (menu) menu.hidden = true;
        trigger?.setAttribute('aria-expanded', 'false');
      }
      if (!e.target.closest('[data-predictive-search-form]')) {
        document.querySelectorAll('[data-predictive-search-results]').forEach((box) => {
          box.hidden = true;
        });
      }

      const cartOpenBtn = e.target.closest('[data-cart-open]');
      if (cartOpenBtn) {
        e.preventDefault();
        refreshCartDrawer();
        setDrawerState(document.getElementById('InpickCartDrawer'), true);
        return;
      }
      if (e.target.closest('[data-cart-close]')) {
        setDrawerState(document.getElementById('InpickCartDrawer'), false);
        return;
      }

      if (e.target.closest('[data-wishlist-open]')) {
        renderWishlistUI();
        setDrawerState(document.getElementById('InpickWishlistDrawer'), true);
        return;
      }
      if (e.target.closest('[data-wishlist-close]')) {
        setDrawerState(document.getElementById('InpickWishlistDrawer'), false);
        return;
      }
      if (e.target.closest('[data-wishlist-clear]')) {
        saveWishlist([]);
        showToast('Wishlist cleared');
        return;
      }

      const wishlistBtn = e.target.closest('[data-wishlist-toggle]');
      if (wishlistBtn) {
        const items = getWishlist();
        const id = wishlistBtn.dataset.productId;
        const exists = items.some((i) => String(i.id) === String(id));
        const next = exists
          ? items.filter((i) => String(i.id) !== String(id))
          : [
              ...items,
              {
                id,
                title: wishlistBtn.dataset.productTitle,
                price: wishlistBtn.dataset.productPrice,
                url: wishlistBtn.dataset.productUrl,
                image: wishlistBtn.dataset.productImage
              }
            ];
        saveWishlist(next);
        showToast(exists ? 'Removed from wishlist' : 'Saved to wishlist');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const menu = document.getElementById('InpickAllCategoriesMenu');
        if (menu) menu.hidden = true;
        setDrawerState(document.getElementById('InpickCartDrawer'), false);
        setDrawerState(document.getElementById('InpickWishlistDrawer'), false);
        setDrawerState(document.getElementById('InpickMobileDrawer'), false);
      }
    });

    document.addEventListener('submit', async (e) => {
      const form = e.target.closest('[data-ajax-cart-form]');
      if (!form) return;
      if (e.submitter && e.submitter.closest('.shopify-payment-button, shopify-accelerated-checkout')) return;
      e.preventDefault();

      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.disabled = true;
      setFormStatus(form, '', '');

      try {
        const formData = new FormData(form);
        const res = await fetch(`${window.INPICK.routes.cart_add_url}.js`, {
          method: 'POST',
          headers: { Accept: 'application/json' },
          body: formData
        });
        const data = await res.json();
        if (!res.ok) {
          const errorMsg = data?.description || 'Unable to add item to cart.';
          setFormStatus(form, errorMsg, 'error');
          showToast(errorMsg);
          return;
        }
        await refreshCartDrawer();
        setFormStatus(form, 'Added to cart successfully.', 'success');
        if (window.INPICK.cartType === 'drawer') {
          setDrawerState(document.getElementById('InpickCartDrawer'), true);
        } else {
          showToast('Added to cart');
        }
      } catch {
        form.submit();
      } finally {
        if (submitBtn) {
          submitBtn.disabled = submitBtn.dataset.variantAvailable === 'false';
        }
      }
    });
  }

  function cleanupSection(sectionEl) {
    if (!sectionEl) return;
    sectionEl.querySelectorAll('[data-hero-carousel]').forEach((carousel) => {
      const id = heroTimers.get(carousel);
      if (id) window.clearInterval(id);
      heroTimers.delete(carousel);
    });
    sectionEl.querySelectorAll('[data-reviews-slider]').forEach((slider) => {
      const id = reviewTimers.get(slider);
      if (id) window.clearInterval(id);
      reviewTimers.delete(slider);
    });
    sectionEl.querySelectorAll('[data-countdown-end]').forEach((el) => {
      const id = countdownTimers.get(el);
      if (id) window.clearInterval(id);
      countdownTimers.delete(el);
    });
  }

  function boot(root = document) {
    bindGlobalListeners();
    initCarousels(root);
    initCountdowns(root);
    initPredictiveSearch(root);
    initHeaderInteractions(root);
    initProductPage(root);
    initFrequentlyBoughtTogether(root);
    initRecentlyViewed(root);
    initReviewSliders(root);
    renderWishlistUI();
  }

  document.addEventListener('DOMContentLoaded', () => boot(document));
  document.addEventListener('shopify:section:unload', (e) => cleanupSection(e.target));
  document.addEventListener('shopify:section:load', (e) => boot(e.target));
})();
